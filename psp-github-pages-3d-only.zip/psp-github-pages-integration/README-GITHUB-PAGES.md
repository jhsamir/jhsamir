# 3D PSP-only portfolio integration (GitHub Pages)

This version removes the original 2D console entirely. The supplied 3D PSP is the only console viewer. It shares the portfolio gallery data, supports the model's controls and keyboard navigation, retains the selected-media lightbox, and preserves the surrounding portfolio design.

## Package contents
- `index.html` — modified portfolio page with the 2D console markup and styles removed.
- `psp.js` — supplied 3D viewer JavaScript, adapted to the single 3D viewer and to notify the page when the selected gallery item changes.
- `assets/models/psp.glb` — supplied model, copied unchanged.
- `.github/workflows/pages.yml` — GitHub Pages workflow.

## Install on your computer
1. Open or clone the GitHub repository that currently hosts your portfolio.
2. Create a backup branch or commit before changing anything.
3. Replace the repository's `index.html` with this package's `index.html`.
4. Add this package's `psp.js` next to `index.html` in the repository root.
5. Copy `assets/models/psp.glb` into your repository at exactly `assets/models/psp.glb`. Do not rename it.
6. Keep your existing `assets/work/`, `assets/img/`, and `assets/audio/` folders. The chat upload did not include those files, and the page still references the existing work images and music. Merge the model into your existing assets folder; do not replace the whole folder with this package's partial assets folder.
7. If your repository already has a GitHub Pages deployment workflow, keep using it and do not add a duplicate. Otherwise copy `.github/workflows/pages.yml` into that exact path.
8. If using the included workflow, go to repository **Settings → Pages** and choose **GitHub Actions** for the deployment source.
9. Commit and push the changes to your publishing branch. Wait for the workflow to finish, then open the published URL.

## Test the site
- There should be only one console: the 3D PSP.
- Drag the console to rotate it.
- Use the PSP buttons or the left/right arrow keys to browse gallery items. Click the canvas first for keyboard navigation.
- Click **View media** to open the selected image/video in the lightbox.
- Click **Open selected** to open the selected item's link.
- Confirm the work images and any audio files load.

## Gallery entries
The `gallery` array remains in `index.html`. Update its image paths to match your own assets. To make a project open a real page, add a `link` property, for example:

```js
{ type:'image', src:'assets/work/nature-01.jpg', alt:'Riverbank framed by trees', link:'projects/riverbank.html' }
```

For video, include a poster so the PSP can display a still frame:

```js
{ type:'video', src:'assets/work/clip.mp4', poster:'assets/work/clip-poster.jpg', alt:'Behind the scenes', link:'projects/reel.html' }
```

## Troubleshooting
- **Model not loading:** confirm the model is at `assets/models/psp.glb` with exact capitalization. GitHub Pages paths are case-sensitive.
- **Images missing:** retain your original `assets/work/...` files.
- **Blank canvas:** use a current Chrome, Edge, or Firefox browser with WebGL enabled. Open DevTools → Console and Network to check for errors. Three.js loads from jsDelivr, so the browser needs internet access.
- **No 3D viewer:** confirm `psp.js` is next to `index.html`, and that the import map plus `<script type="module" src="./psp.js"></script>` are present at the bottom of the page.

## Model integrity
SHA-256 of the packaged `psp.glb`: `aca80b66c4c637acf62ff22cb4585a559b2349e4d85946f63e92aa71435a5470`
